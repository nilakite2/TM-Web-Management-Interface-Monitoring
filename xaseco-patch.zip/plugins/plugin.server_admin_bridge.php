<?php
/**
 * plugin.server_admin_bridge.php
 * XAseco 1.16: expose a helper and whitelist the dedicated server login as MasterAdmin,
 * so /admin commands sent via ChatSend can be authorized — without injecting a fake player.
 */

Aseco::registerEvent('onSync', 'sai_setup_server_login');

/** True if $login is the dedicated server's own account. */
if (!function_exists('sai_is_server_login')) {
  function sai_is_server_login($login) {
    global $aseco;
    if (!is_string($login) || $login === '') return false;
    return (strtolower($login) === strtolower($aseco->server->serverlogin));
  }
}

function sai_setup_server_login($aseco) {
  // Server login is only known after sync (TMF)
  $login = isset($aseco->server->serverlogin) ? $aseco->server->serverlogin : '';
  if ($login === '') return;

  // Ensure server login is considered a MasterAdmin (runtime only)
  if (!isset($aseco->masteradmin_list['TMLOGIN'])) $aseco->masteradmin_list['TMLOGIN'] = array();
  if (!in_array($login, $aseco->masteradmin_list['TMLOGIN'], true)) {
    $aseco->masteradmin_list['TMLOGIN'][] = $login;

    if (!isset($aseco->masteradmin_list['IPADDRESS'])) $aseco->masteradmin_list['IPADDRESS'] = array();
    $aseco->masteradmin_list['IPADDRESS'][] = ''; // keep arrays aligned; '' => any IP
  }

  $aseco->console('[SAI] Server login "{1}" whitelisted as MasterAdmin (no synthetic player injected).', $login);
}